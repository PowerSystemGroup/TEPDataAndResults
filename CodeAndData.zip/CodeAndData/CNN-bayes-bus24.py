# conding=utf-8
# Time: 2024/5/15 13:36

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
import torch
import numpy as np
import tqdm
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score, mean_absolute_percentage_error
import optuna

# Retrieve data
file_path = 'TrainingDataY.xlsx'
df = pd.read_excel(file_path)

# Specify input and output data
y_data = df.iloc[:, 56:91]
x_data = df.iloc[:, 0:56]

# Splitting the training set, validation set and test set
x_train, x_temp, y_train, y_temp = train_test_split(x_data, y_data, test_size=0.2, random_state=22, shuffle=True)
x_val, x_test, y_val, y_test = train_test_split(x_temp, y_temp, test_size=0.5, random_state=22, shuffle=True)

# Data normalization
scaler_x = MinMaxScaler()
scaler_y = MinMaxScaler()
x_train_normalized = scaler_x.fit_transform(x_train)
x_val_normalized = scaler_x.transform(x_val)
x_test_normalized = scaler_x.transform(x_test)
y_train_normalized = scaler_y.fit_transform(y_train)
y_val_normalized = scaler_y.transform(y_val)
y_test_normalized = scaler_y.transform(y_test)

# Converting data to tensor and moving it to the GPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
x_train_tensor = torch.FloatTensor(x_train_normalized).unsqueeze(1).to(device)
y_train_tensor = torch.FloatTensor(y_train_normalized).to(device)
x_val_tensor = torch.FloatTensor(x_val_normalized).unsqueeze(1).to(device)
y_val_tensor = torch.FloatTensor(y_val_normalized).to(device)
x_test_tensor = torch.FloatTensor(x_test_normalized).unsqueeze(1).to(device)
y_test_tensor = torch.FloatTensor(y_test_normalized).to(device)

# Define the CNN model
class CNNModel(torch.nn.Module):
    def __init__(self, input_size, output_size, c1, c2, c3, c4):
        super(CNNModel, self).__init__()
        self.conv1 = torch.nn.Conv1d(1, c1, kernel_size=3)
        self.conv2 = torch.nn.Conv1d(c1, c2, kernel_size=3)
        self.conv3 = torch.nn.Conv1d(c2, c3, kernel_size=3)
        self.conv4 = torch.nn.Conv1d(c3, c4, kernel_size=3)
        self.pool1 = torch.nn.MaxPool1d(kernel_size=1)
        self.pool = torch.nn.MaxPool1d(kernel_size=2)
        self.fc1 = torch.nn.Linear(c4 * ((input_size - 4) // 2 - 2), output_size)
        self.relu = torch.nn.ReLU()

    def forward(self, x):
        x = self.relu(self.conv1(x))
        x = self.pool1(x)
        x = self.relu(self.conv2(x))
        x = self.pool1(x)
        x = self.relu(self.conv3(x))
        x = self.pool1(x)
        x = self.relu(self.conv4(x))
        x = self.pool(x)
        x = x.view(x.size(0), -1)
        x = self.fc1(x)
        return x

def objective(trial, n_feature, n_output):
    # Sample hyperparameters
    lr = trial.suggest_float('lr', 1e-6, 1e-2)
    batch_size = trial.suggest_categorical('batch_size', [16, 32, 64])
    c1 = trial.suggest_int('c1', 1, 130)
    c2 = trial.suggest_int('c2', 1, 130)
    c3 = trial.suggest_int('c3', 1, 130)
    c4 = trial.suggest_int('c4', 1, 130)
    epochs = 500

    # Initialization Model
    net = CNNModel(input_size=n_feature, output_size=n_output, c1=c1, c2=c2, c3=c3, c4=c4).to(device)
    optimizer = torch.optim.Adam(net.parameters(), lr=lr)
    loss_fun = torch.nn.MSELoss()

    # Building the data loader
    train_loader = torch.utils.data.DataLoader(
        torch.utils.data.TensorDataset(x_train_tensor, y_train_tensor),
        batch_size=batch_size,
        shuffle=True
    )

    # Training model
    val_loss_steps = np.zeros(epochs)
    for epoch in tqdm.tqdm(range(epochs), colour='BLUE', postfix='============Training epoch============'):
        epoch_loss = 0.0
        for batch_x, batch_y in train_loader:
            y_pred = net(batch_x)
            loss = loss_fun(y_pred, batch_y)
            epoch_loss += loss.item()
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        # Calculate the loss on the validation set
        with torch.no_grad():
            y_val_pred = net(x_val_tensor)
            val_loss = loss_fun(y_val_pred, y_val_tensor)
            val_loss_steps[epoch] = val_loss.item()
    return val_loss_steps[-1]  # Returns the validation set loss of the last epoch

# Perform Bayesian optimization
study = optuna.create_study(direction='minimize')
study.optimize(lambda trial: objective(trial, 56, 35), n_trials=100)

# Printing Optimal Hyperparameters
print("Best trial:")
trial = study.best_trial
print("  Value: {}".format(trial.value))
print("  Params: ")
for key, value in trial.params.items():
    print("    {}: {}".format(key, value))

# Get the best model (the following part is for reference only and will actually be run in separate code)
best_lr = trial.params['lr']
best_batch_size = trial.params['batch_size']
best_c1 = trial.params['c1']
best_c2 = trial.params['c2']
best_c3 = trial.params['c3']
best_c4 = trial.params['c4']
epochs = 1000
best_net = CNNModel(input_size=56, output_size=35, c1=best_c1, c2=best_c2, c3=best_c3, c4=best_c4).to(device)
best_optimizer = torch.optim.Adam(best_net.parameters(), lr=best_lr)
best_loss_fun = torch.nn.MSELoss()

# Building the data loader
best_train_loader = torch.utils.data.DataLoader(
    torch.utils.data.TensorDataset(x_train_tensor, y_train_tensor),
    batch_size=best_batch_size,
    shuffle=True
)

# Training the best model
best_loss_steps = np.zeros(epochs)
best_val_loss_steps = np.zeros(epochs)
for epoch in tqdm.tqdm(range(epochs), colour='BLUE', postfix='============Training epoch============'):
    epoch_loss = 0.0
    for batch_x, batch_y in best_train_loader:
        y_pred = best_net(batch_x)
        loss = best_loss_fun(y_pred, batch_y)
        epoch_loss += loss.item()
        best_optimizer.zero_grad()
        loss.backward()
        best_optimizer.step()
    best_loss_steps[epoch] = epoch_loss / len(best_train_loader)

    # Calculate the loss on the validation set
    with torch.no_grad():
        y_val_pred = best_net(x_val_tensor)
        val_loss = best_loss_fun(y_val_pred, y_val_tensor)
        best_val_loss_steps[epoch] = val_loss.item()

# Plotting loss curves
plt.plot(best_loss_steps, label='Training Loss')
plt.plot(best_val_loss_steps, label='Validation Loss')
plt.title("Best Model Training and Validation Loss")
plt.xlabel("Epochs")
plt.ylabel("Loss")
plt.legend()
plt.savefig('best_model_training_validation_loss.png')
plt.show()

# Testing the best models
with torch.no_grad():
    y_pred_test = best_net(x_test_tensor).detach().cpu().numpy()
y_test_inverse = scaler_y.inverse_transform(y_test_tensor.cpu().numpy())
y_pred_test1 = scaler_y.inverse_transform(y_pred_test)

"""------------------Evaluation of indicators------------------"""
# Indicators before rounding
mse = mean_squared_error(y_test_inverse, y_pred_test1)
mae = mean_absolute_error(y_test_inverse, y_pred_test1)
ss_total = np.sum((y_test_inverse - np.mean(y_test_inverse)) ** 2)
ss_residual = np.sum((y_test_inverse - y_pred_test1) ** 2)
r_squared1 = 1 - (ss_residual / ss_total)
# Indicators after rounding
y1 = [[] for i in range(1175)]
for t, a in zip(y_pred_test1, range(len(y_pred_test1))):
    for y in t:
        y1[a].append(np.around(y, 0))
y1 = np.array(y1)
mseJ = mean_squared_error(y_test_inverse, y1)
maeJ = mean_absolute_error(y_test_inverse, y1)
ss_total = np.sum((y_test_inverse - np.mean(y_test_inverse)) ** 2)
ss_residual = np.sum((y_test_inverse - y1) ** 2)
r_squaredJ = 1 - (ss_residual / ss_total)
print("\n")
print("==========Indicators before rounding==========")
print("R-squared:", r_squared1)
print(f"MSE: {mse}")
print(f"MAE: {mae}")
print("==========Indicators after rounding==========")
print("R-squared:", r_squaredJ)
print(f"MSE: {mseJ}")
print(f"MAE: {maeJ}")

# Plotting Scatter Plots
plt.title("Actual vs Predicted Scatter Plot")
plt.xlabel("Sample Index")
plt.ylabel("Value")
for i in range(10):  # Plotting the scatterplot of the first 10 samples
    plt.scatter(range(len(y_test_inverse[i])), y_test_inverse[i], label="Actual", color='red', alpha=0.5)
    plt.scatter(range(len(y1[i])), y1[i], label="Predicted", color='blue', alpha=0.5)
    plt.legend()
    plt.show()
