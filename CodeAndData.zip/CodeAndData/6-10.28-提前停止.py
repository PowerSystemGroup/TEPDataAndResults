# conding=utf-8
# Time: 2024/10/29 15:06

# conding=utf-8
# Time: 2024/10/28 22:10

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
import torch
import numpy as np
import tqdm
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score, mean_absolute_percentage_error
import time
start = time.perf_counter()

# Hyperparameter
lr = 0.00026
epochs = 1000
n_feature = 17
n_output = 15
batch_size = 32
c1 = 99
c2 = 67
c3 = 103
c4 = 53
early_stopping = True  # Enable early stopping
patience = 50  # Number of epochs with no improvement after which training will be stopped

R2X = []
MseX = []
MaeX = []

for i in range(1):
    print(f"===============LOOP==============: {i+1}")

    # Retrieve data
    file_path = 'TrainingDataX11.xlsx'
    df = pd.read_excel(file_path)

    # Specify input and output data
    y_data = df.iloc[:, 17:32]
    x_data = df.iloc[:, 0:17]

    # Splitting the training set, validation set and test set
    x_train, x_temp, y_train, y_temp = train_test_split(x_data, y_data, test_size=0.2, random_state=22, shuffle=True)
    x_val, x_test, y_val, y_test = train_test_split(x_temp, y_temp, test_size=0.5, random_state=22, shuffle=True)

    # Data normalization
    scaler_x = MinMaxScaler()
    scaler_y = MinMaxScaler()
    x_train_normalized = scaler_x.fit_transform(x_train)
    x_val_normalized = scaler_x.transform(x_val)
    x_test_normalized = scaler_x.transform(x_test)
    y_train_normalized = scaler_y.fit_transform(y_train)
    y_val_normalized = scaler_y.transform(y_val)
    y_test_normalized = scaler_y.transform(y_test)

    # Converting data to tensor and moving it to the GPU
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    x_train_tensor = torch.FloatTensor(x_train_normalized).unsqueeze(1).to(device)
    y_train_tensor = torch.FloatTensor(y_train_normalized).to(device)
    x_val_tensor = torch.FloatTensor(x_val_normalized).unsqueeze(1).to(device)
    y_val_tensor = torch.FloatTensor(y_val_normalized).to(device)
    x_test_tensor = torch.FloatTensor(x_test_normalized).unsqueeze(1).to(device)
    y_test_tensor = torch.FloatTensor(y_test_normalized).to(device)

    # Define the CNN model
    class CNNModel(torch.nn.Module):
        def __init__(self, input_size, output_size):
            super(CNNModel, self).__init__()
            self.conv1 = torch.nn.Conv1d(1, c1, kernel_size=3)
            self.conv2 = torch.nn.Conv1d(c1, c2, kernel_size=3)
            self.conv3 = torch.nn.Conv1d(c2, c3, kernel_size=3)
            self.conv4 = torch.nn.Conv1d(c3, c4, kernel_size=3)
            self.pool1 = torch.nn.MaxPool1d(kernel_size=1)
            self.pool = torch.nn.MaxPool1d(kernel_size=2)
            # self.fc1 = torch.nn.Linear(c4 * ((((((input_size - 4) // 2) // 2) // 2) // 2) - 2), output_size)
            self.fc1 = torch.nn.Linear(c4 * ((input_size - 4) // 2 - 2), output_size)
            self.relu = torch.nn.ReLU()

        def forward(self, x):
            x = self.relu(self.conv1(x))
            x = self.pool1(x)
            x = self.relu(self.conv2(x))
            x = self.pool1(x)
            x = self.relu(self.conv3(x))
            x = self.pool1(x)
            x = self.relu(self.conv4(x))
            x = self.pool(x)
            x = x.view(x.size(0), -1)
            x = self.fc1(x)
            return x

    # Initialize model
    net = CNNModel(input_size=n_feature, output_size=n_output).to(device)
    optimizer = torch.optim.Adam(net.parameters(), lr=lr)
    loss_fun = torch.nn.MSELoss()

    # Data loader for training
    train_loader = torch.utils.data.DataLoader(
        torch.utils.data.TensorDataset(x_train_tensor, y_train_tensor),
        batch_size=batch_size,
        shuffle=True
    )

    # Training model with early stopping
    loss_steps = np.zeros(epochs)
    val_loss_steps = np.zeros(epochs)
    best_val_loss = float('inf')
    epochs_no_improve = 0

    for epoch in tqdm.tqdm(range(epochs), colour='BLUE', postfix='============Training epoch============'):
        epoch_loss = 0.0
        for batch_x, batch_y in train_loader:
            y_pred = net(batch_x)
            loss = loss_fun(y_pred, batch_y)
            epoch_loss += loss.item()
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        loss_steps[epoch] = epoch_loss / len(train_loader)

        # Calculate validation loss
        with torch.no_grad():
            y_val_pred = net(x_val_tensor)
            val_loss = loss_fun(y_val_pred, y_val_tensor)
            val_loss_steps[epoch] = val_loss.item()

        # Check if validation loss improved
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            epochs_no_improve = 0  # reset count
        else:
            epochs_no_improve += 1

        # Early stopping
        if early_stopping and epochs_no_improve >= patience:
            print(f"Early stopping at epoch {epoch+1}")
            break

    # # Plotting loss curves
    # plt.plot(loss_steps[:epoch+1], label='Training Loss')
    # plt.plot(val_loss_steps[:epoch+1], label='Validation Loss')
    # plt.title("Training and Validation Loss")
    # plt.xlabel("Epochs")
    # plt.ylabel("Loss")
    # plt.legend()
    # plt.savefig('training_validation_loss.png')
    # plt.show()

    # Test the model
    with torch.no_grad():
        y_pred_test = net(x_test_tensor).detach().cpu().numpy()
    y_test_inverse = scaler_y.inverse_transform(y_test_tensor.cpu().numpy())
    y_pred_test1 = scaler_y.inverse_transform(y_pred_test)

    # Evaluation of indicators
    mse = mean_squared_error(y_test_inverse, y_pred_test1)
    mae = mean_absolute_error(y_test_inverse, y_pred_test1)
    ss_total = np.sum((y_test_inverse - np.mean(y_test_inverse)) ** 2)
    ss_residual = np.sum((y_test_inverse - y_pred_test1) ** 2)
    r_squared1 = 1 - (ss_residual / ss_total)

    # Indicators after rounding
    y1 = [[] for i in range(703)]
    for t, a in zip(y_pred_test1, range(len(y_pred_test1))):
        for y in t:
            y1[a].append(np.around(y, 0))
    y1 = np.array(y1)
    mseJ = mean_squared_error(y_test_inverse, y1)
    maeJ = mean_absolute_error(y_test_inverse, y1)
    ss_total = np.sum((y_test_inverse - np.mean(y_test_inverse)) ** 2)
    ss_residual = np.sum((y_test_inverse - y1) ** 2)
    r_squaredJ = 1 - (ss_residual / ss_total)

    # print("\n==========Indicators before rounding==========")
    # print("R-squared:", r_squared1)
    # print(f"MSE: {mse}")
    # print(f"MAE: {mae}")
    print("==========Indicators after rounding==========")
    print("R-squared:", r_squaredJ)
    print(f"MSE: {mseJ}")
    print(f"MAE: {maeJ}")

    R2X.append(r_squaredJ)
    MseX.append(mseJ)
    MaeX.append(maeJ)

    # Plotting Scatter Plots
    # plt.title("Actual vs Predicted Scatter Plot")
    # plt.xlabel("Sample Index")
    # plt.ylabel("Value")
    # for i in range(10):  # Plotting the scatterplot of the first 10 samples
    #     plt.scatter(range(len(y_test_inverse[i])), y_test_inverse[i], label="Actual", color='red', alpha=0.5)
    #     plt.scatter(range(len(y1[i])), y1[i], label="Predicted", color='blue', alpha=0.5)
    #     plt.legend()
    #     plt.show()

R2X = np.array(R2X)
MseX = np.array(MseX)
MaeX = np.array(MaeX)
end = time.perf_counter()
runTime = (end - start)
print("running time：", runTime)
