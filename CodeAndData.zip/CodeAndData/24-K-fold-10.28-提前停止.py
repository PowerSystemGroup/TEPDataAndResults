# conding=utf-8
# Time: 2024/10/28 21:59

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import KFold
from sklearn.preprocessing import MinMaxScaler
import torch
import numpy as np
import tqdm
from sklearn.metrics import mean_squared_error, mean_absolute_error

# Hyperparameter
lr = 0.00092
epochs = 1000
n_feature = 56
n_output = 35
batch_size = 64
c1 = 97
c2 = 120
c3 = 82
c4 = 112
k_folds = 5  # Set K for K-Fold Cross Validation
patience = 30  

# Retrieve data
file_path = 'TrainingDataY.xlsx'
df = pd.read_excel(file_path)

# Specify input and output data
y_data = df.iloc[:, 56:91]
x_data = df.iloc[:, 0:56]

# Data normalization
scaler_x = MinMaxScaler()
scaler_y = MinMaxScaler()
x_data_normalized = scaler_x.fit_transform(x_data)
y_data_normalized = scaler_y.fit_transform(y_data)

# Convert to tensors and move to GPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
x_data_tensor = torch.FloatTensor(x_data_normalized).unsqueeze(1).to(device)
y_data_tensor = torch.FloatTensor(y_data_normalized).to(device)

# Define the CNN model
class CNNModel(torch.nn.Module):
    def __init__(self, input_size, output_size):
        super(CNNModel, self).__init__()
        self.conv1 = torch.nn.Conv1d(1, c1, kernel_size=3)
        self.conv2 = torch.nn.Conv1d(c1, c2, kernel_size=3)
        self.conv3 = torch.nn.Conv1d(c2, c3, kernel_size=3)
        self.conv4 = torch.nn.Conv1d(c3, c4, kernel_size=3)
        self.pool1 = torch.nn.MaxPool1d(kernel_size=1)
        self.pool = torch.nn.MaxPool1d(kernel_size=2)
        # self.fc1 = torch.nn.Linear(c4 * ((((((input_size - 4) // 2) // 2) // 2) // 2) - 2), output_size)
        self.fc1 = torch.nn.Linear(c4 * ((input_size - 4) // 2 - 2), output_size)
        self.relu = torch.nn.ReLU()

    def forward(self, x):
        x = self.relu(self.conv1(x))
        x = self.pool1(x)
        x = self.relu(self.conv2(x))
        x = self.pool1(x)
        x = self.relu(self.conv3(x))
        x = self.pool1(x)
        x = self.relu(self.conv4(x))
        x = self.pool(x)
        x = x.view(x.size(0), -1)
        x = self.fc1(x)
        return x

# Define KFold cross-validator
kf = KFold(n_splits=k_folds, shuffle=True, random_state=22)

# Initialize lists to store results
fold_train_losses = []
fold_val_losses = []

for fold, (train_idx, val_idx) in enumerate(kf.split(x_data_tensor)):
    print(f'Fold {fold+1}/{k_folds}')

    # Create dataloaders for this fold
    x_train_fold, x_val_fold = x_data_tensor[train_idx], x_data_tensor[val_idx]
    y_train_fold, y_val_fold = y_data_tensor[train_idx], y_data_tensor[val_idx]

    train_loader = torch.utils.data.DataLoader(
        torch.utils.data.TensorDataset(x_train_fold, y_train_fold),
        batch_size=batch_size,
        shuffle=True
    )

    # Reinitialize model for each fold
    net = CNNModel(input_size=n_feature, output_size=n_output).to(device)
    optimizer = torch.optim.Adam(net.parameters(), lr=lr)
    loss_fun = torch.nn.MSELoss()

    # Training model for the current fold with early stopping
    best_val_loss = float('inf')
    best_model_state = None
    patience_counter = 0
    loss_steps = np.zeros(epochs)
    val_loss_steps = np.zeros(epochs)

    for epoch in tqdm.tqdm(range(epochs), colour='BLUE', postfix=f'============Training Fold {fold+1} Epoch============'):
        epoch_loss = 0.0
        for batch_x, batch_y in train_loader:
            y_pred = net(batch_x)
            loss = loss_fun(y_pred, batch_y)
            epoch_loss += loss.item()
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        loss_steps[epoch] = epoch_loss / len(train_loader)

        # Calculate the loss on the validation set
        with torch.no_grad():
            y_val_pred = net(x_val_fold)
            val_loss = loss_fun(y_val_pred, y_val_fold)
            val_loss_steps[epoch] = val_loss.item()

        # Early stopping logic
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_model_state = net.state_dict()  # Save the best model state
            patience_counter = 0  # Reset the counter if validation loss improves
        else:
            patience_counter += 1  # Increment the counter if no improvement
            if patience_counter >= patience:
                print(f"Early stopping at epoch {epoch+1}")
                break

    # Load the best model state after early stopping
    net.load_state_dict(best_model_state)

    # Store the final training and validation loss of the current fold
    fold_train_losses.append(loss_steps[:epoch+1].mean())
    fold_val_losses.append(best_val_loss.item())

    # Plot training and validation loss curves for this fold
    plt.plot(loss_steps[:epoch+1], label=f'Training Loss (Fold {fold+1})')
    plt.plot(val_loss_steps[:epoch+1], label=f'Validation Loss (Fold {fold+1})')
    plt.title(f"Training and Validation Loss for Fold {fold+1}")
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.legend()
    plt.savefig(f'fold_{fold+1}_training_validation_loss.png')
    plt.show()

# Print the results for each fold
print(f"\n==========K-Fold Cross Validation Results ({k_folds} Folds)==========")
for fold in range(k_folds):
    print(f"Fold {fold+1} - Training Loss: {fold_train_losses[fold]} | Validation Loss: {fold_val_losses[fold]}")

print(f"Average Training Loss: {np.mean(fold_train_losses)}")
print(f"Average Validation Loss: {np.mean(fold_val_losses)}")

# Test the model on the final fold
with torch.no_grad():
    y_pred_test = net(x_val_fold).detach().cpu().numpy()
y_test_inverse = scaler_y.inverse_transform(y_val_fold.cpu().numpy())
y_pred_test1 = scaler_y.inverse_transform(y_pred_test)

# Evaluation of indicators
mse = mean_squared_error(y_test_inverse, y_pred_test1)
mae = mean_absolute_error(y_test_inverse, y_pred_test1)
ss_total = np.sum((y_test_inverse - np.mean(y_test_inverse)) ** 2)
ss_residual = np.sum((y_test_inverse - y_pred_test1) ** 2)
r_squared1 = 1 - (ss_residual / ss_total)

# Print results
print("\n==========Indicators after K-Fold Validation==========")
print("R-squared:", r_squared1)
print(f"MSE: {mse}")
print(f"MAE: {mae}")
